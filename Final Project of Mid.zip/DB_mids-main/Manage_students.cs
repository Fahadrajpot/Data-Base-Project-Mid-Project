﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_mids_project
{
    public partial class Manage_students : Form
    {
        public Manage_students()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;

        }

        private void Manage_students_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void hOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.WindowState = FormWindowState.Maximized;

            form.Show();
            Visible = false;
        }

        private void mANAGESTUDENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manage_students manage_Students = new Manage_students();
            manage_Students.WindowState = FormWindowState.Maximized;

            manage_Students.Show();
            Visible = false;
        }

        private void mANAGERUBRICSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubrics manage_ = new ManageRubrics();
            manage_.WindowState = FormWindowState.Maximized;

            manage_.Show();
            Visible = false;
        }

        private void mANAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubricsLevel man = new ManageRubricsLevel();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;

        }

        private void mARKEVALUATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MarkEvaluation ma = new MarkEvaluation();
            ma.WindowState = FormWindowState.Maximized;

            ma.Show();
            Visible = false;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ManageCLO mana = new ManageCLO();
            mana.WindowState = FormWindowState.Maximized;

            mana.Show();
            Visible=false;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ManageAssesment mana = new ManageAssesment();
            mana.WindowState = FormWindowState.Maximized;
            mana.Show();
            Visible=false;
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddStudent2 addStudents = new AddStudent2();
            addStudents.WindowState = FormWindowState.Maximized;
            addStudents.Show();
            Visible = false;
        }

        private void mANAGESTUDENTSToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void mANAGERUBRICSToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            Update_Student2 updateStudents = new Update_Student2();
            updateStudents.WindowState = FormWindowState.Maximized;
            updateStudents.Show();
            Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Student_attendance att = new Student_attendance();
            att.WindowState = FormWindowState.Maximized;
            att.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Delete_student del = new Delete_student();
            del.WindowState = FormWindowState.Maximized;
            del.Show();

            Visible=false;
        }

        private void hOMEToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.WindowState = FormWindowState.Maximized;
            form1.Show();
            Visible = false;
        }

        private void AddStudent_btn_Click(object sender, EventArgs e)
        {
            Manage_students newa = new Manage_students();
            newa.WindowState = FormWindowState.Maximized;
            newa.Show();
            Visible = false;
        }

        private void AddTeacher_btn_Click(object sender, EventArgs e)
        {
            ManageCLO newa = new ManageCLO();
            newa.WindowState = FormWindowState.Maximized;
            newa.Show();
            Visible = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            ManageRubrics manage = new ManageRubrics();
            manage.WindowState = FormWindowState.Maximized;

            manage.Show();
            Visible = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ManageRubricsLevel man = new ManageRubricsLevel();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ManageAssesment man = new ManageAssesment();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MarkEvaluation markEvaluation = new MarkEvaluation();
            markEvaluation.WindowState = FormWindowState.Maximized;
            markEvaluation.Show();
            Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
