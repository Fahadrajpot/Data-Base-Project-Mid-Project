﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_mids_project
{
    public partial class UpdateStudents : Form
    {
        public UpdateStudents()
        {
            InitializeComponent();
        }

        private void hOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.WindowState = FormWindowState.Maximized;
            form1.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=ANASSAAHI\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            string var = textBox3.Text;
            string query = "SELECT * FROM Student where RegistrationNumber ='" + var + "';";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                dataGridView1.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }



        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constr = "Data Source=ANASSAAHI\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string roll = textBox3.Text;
            string Fname = textBox5.Text;
            string Lname = textBox4.Text;
            string RegistrationNumber = textBox6.Text;
            string Contact = textBox1.Text;
            string Email = textBox2.Text;
            
            SqlCommand cmd = new SqlCommand("update Student set FirstName = '" + Fname + "',LastName = '" + Lname + "',Contact = " + Contact + ",Email = '" + Email + "',RegistrationNumber = '" + RegistrationNumber + "' WHERE RegistrationNumber ='"+roll+"' ;", con);



            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Updated!");
            printStudent();
        }
        private void printStudent()
        {
            string connectionString = "Data Source=ANASSAAHI\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "SELECT * FROM Student";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                dataGridView1.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void UpdateStudents_Load(object sender, EventArgs e)
        {

        }
    }
}
