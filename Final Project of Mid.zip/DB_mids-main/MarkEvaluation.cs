﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;



namespace database_mids_project
{
    public partial class MarkEvaluation : Form
    {
        private string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
        public MarkEvaluation()
        {
            WindowState = FormWindowState.Maximized;

            InitializeComponent();
            fillStudentCombo();
            fillAssessmentCombo();
            fillAssessmentComponent();
            fillRubricDetail();
            fillRubricID();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void hOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.WindowState = FormWindowState.Maximized;

            f.Show();
            Visible = false;
        }

        private void MarkEvaluation_Load(object sender, EventArgs e)
        {
            
            
        }
        private void fillStudentCombo()
        {

            string query = "SELECT * FROM Student";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    studentcombo.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }

        private void fillAssessmentCombo()
        {
            string query = "SELECT * FROM Assessment";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    assessmentcombo.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }

        private void fillAssessmentComponent()
        {
            string query = "SELECT * FROM AssessmentComponent";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    componentcombo.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }


        private void fillRubricDetail()
        {
            string query = "SELECT * FROM Rubric";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    rubricdetailcombo.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }


        private void fillRubricID()
        {
            string query = "SELECT * FROM RubricLevel";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader["id"]);
                    rubricidcombo.Items.Add(id);

                }


                reader.Close();
                connection.Close();
            }
        }


        private bool ValidateStudent()
        {
            if (studentcombo.SelectedItem == null || studentcombo.SelectedItem.ToString() == "")
            {
                errorProvider1.SetError(studentcombo, "It cannot be empty.");
                return false;
            }
            else
            {
                errorProvider1.SetError(studentcombo, string.Empty);

            }
            return true;
        }

        private bool ValidateAssessment()
        {
            if (assessmentcombo.SelectedItem == null || assessmentcombo.SelectedItem.ToString() == "")
            {
                errorProvider2.SetError(assessmentcombo, "It cannot be empty.");
                return false;
            }
            else
            {
                errorProvider2.SetError(assessmentcombo, string.Empty);

            }
            return true;
        }

        private bool ValidateComponent()
        {
            if (componentcombo.SelectedItem == null || componentcombo.SelectedItem.ToString() == "")
            {
                errorProvider3.SetError(componentcombo, "It cannot be empty.");
                return false;
            }
            else
            {
                errorProvider3.SetError(componentcombo, string.Empty);

            }
            return true;
        }

        private bool ValidateRDetail()
        {
            if (rubricdetailcombo.SelectedItem == null || rubricdetailcombo.SelectedItem.ToString() == "")
            {
                errorProvider4.SetError(rubricdetailcombo, "It cannot be empty.");
                return false;
            }
            else
            {
                errorProvider4.SetError(rubricdetailcombo, string.Empty);

            }
            return true;
        }

        private bool ValidateRLevel()
        {
            if (rubriclevelcombo.SelectedItem == null || rubriclevelcombo.SelectedItem.ToString() == "")
            {
                errorProvider5.SetError(rubriclevelcombo, "It cannot be empty.");
                return false;
            }
            else
            {
                errorProvider5.SetError(rubriclevelcombo, string.Empty);

            }
            return true;
        }

        private bool ValidateRLevelId()
        {
            if (rubricidcombo.SelectedItem == null || rubricidcombo.SelectedItem.ToString() == "")
            {
                errorProvider6.SetError(rubricdetailcombo, "It cannot be empty.");
                return false;
            }
            else
            {
                errorProvider6.SetError(rubricdetailcombo, string.Empty);

            }
            return true;
        }

        private int getStudentId()
        {
            int studentId = -1;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from Student where FirstName = @name", con);
            cmd.Parameters.AddWithValue("@name", studentcombo.Text);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                studentId = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return studentId;

        }

        private int getComponentMarks()
        {
            int Marks = -1;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select totalMarks from AssessmentComponent where Name = @name", con);
            cmd.Parameters.AddWithValue("@name", componentcombo.Text);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                Marks = Convert.ToInt32(reader["totalMarks"]);
            }

            con.Close();

            return Marks;
        }

        private int getRubricValue()
        {
            if (rubriclevelcombo.Text == "Unsatisfactory")
            {
                return 1;
            }
            else if (rubriclevelcombo.Text == "Fair")
            {
                return 2;
            }
            else if (rubriclevelcombo.Text == "Good")
            {
                return 3;
            }
            else { return 4; }
        }

        private int getMaxRubric()
        {
            int max = -1;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT MAX(measurementLevel) FROM rubriclevel WHERE id = @id", con);
                cmd.Parameters.AddWithValue("@id", rubricidcombo.Text);

                object result = cmd.ExecuteScalar();
                if (result != DBNull.Value) 
                {
                    max = Convert.ToInt32(result);
                }
                con.Close();
            }

            return max;
        }


        private int calculateObtainedMarks()
        {
            int rvalue = getRubricValue();
            int marks = getComponentMarks();
            int maxrubricValue = getMaxRubric();

            int result = (rvalue / maxrubricValue) * marks;
            return result;
        }

        
        private void saveEvaluation()
        {
            int stdID = getStudentId();
            int assessmentComponentID = getComponentId();
            int marks = calculateObtainedMarks();

            using (SqlConnection con = new SqlConnection(connectionString))
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO StudentResult (StudentId, AssessmentComponentId, RubricMeasurementId, EvaluationDate, ObtainedMarks) VALUES (@stdID, @ACID, @rubicLevelId, GetDate(), @marks)", con);
                cmd.Parameters.AddWithValue("@stdID", stdID);
                cmd.Parameters.AddWithValue("@ACID", assessmentComponentID);
                cmd.Parameters.AddWithValue("@rubicLevelId", rubricidcombo.Text);
                cmd.Parameters.AddWithValue("@marks", marks);
                if (!checkResult())
                {
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Successfully Saved!");
                    reset();
                    displayResult();
                }
                else
                {
                    con.Close();
                    MessageBox.Show("This Result Already Exist!");
                    reset();
                    displayResult();
                }

            }



        }

        private void reset()
        {

            rubricidcombo.Items.Clear();
            rubriclevelcombo.Items.Clear();
            rubricdetailcombo.Items.Clear();
            assessmentcombo.Items.Clear();
            componentcombo.Items.Clear();
        }

        private int getComponentId()
        {
            int compId = -1;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from AssessmentComponent where name = @name", con);
            cmd.Parameters.AddWithValue("@name", componentcombo.Text);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                compId = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return compId;
        }

        private void Marks()
        {

            int marks = getComponentMarks();
        }
        private void displayResult()
        {
            string query = "SELECT * FROM StudentResult where studentId = @id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@id", getStudentId());
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                studentData.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }

        private bool checkResult()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM StudentResult WHERE StudentId = @id AND AssessmentComponentId = @ACID AND RubricMeasurementId= @rid", con);
            cmd.Parameters.AddWithValue("@id", getStudentId());
            cmd.Parameters.AddWithValue("@ACID", getComponentId());
            cmd.Parameters.AddWithValue("@rid", rubricidcombo.Text);
            int count = (int)(cmd.ExecuteScalar());

            con.Close();
            return count > 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!ValidateStudent())
            {
                return;
            }
            displayResult();
        }

        private void save_Click(object sender, EventArgs e)
        {
            if (!ValidateStudent())
            {
                return;
            }
            if (!ValidateAssessment())
            {
                return;
            }
            if (!ValidateRLevel())
            {
                return;
            }
            if (!ValidateRLevelId())
            {
                return;
            }
            if (!ValidateComponent())
            {
                return;
            }
            if (!ValidateRDetail())
            {
                return;
            }
            saveEvaluation();
            displayResult();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void hOMEToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.WindowState = FormWindowState.Maximized;

            form.Show();
            Visible = false;
        }

        private void mANAGESTUDENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manage_students manage_Students = new Manage_students();
            manage_Students.WindowState = FormWindowState.Maximized;

            manage_Students.Show();
            Visible=false;
        }

        private void mANAGERUBRICSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubrics manage_ = new ManageRubrics();
            manage_.WindowState = FormWindowState.Maximized;


            manage_.Show();
            Visible=false;
        }

        private void mANAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubricsLevel manage_ =    new ManageRubricsLevel();
            manage_.WindowState = FormWindowState.Maximized;

            manage_.Show();
            Visible=false;
        }

        private void mARKEVALUATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MarkEvaluation markEvaluation = new MarkEvaluation();
            markEvaluation.WindowState = FormWindowState.Maximized;

            markEvaluation.Show();
            Visible = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           /* // Create an instance of the Crystal Report
            CrystalReport1 report1 = new CrystalReport1();

            // Load the Crystal Report file
            report1.Load("D:\\for study\\Study2ndSemester\\DB\\DB_mids-main[1]\\DB_mids-main\\CrystalReport1.rpt");

            // Create an instance of CrystalReportViewer
            CrystalReportViewer crystalReportViewer = new CrystalReportViewer();

            // Set the report source for the viewer
            crystalReportViewer.ReportSource = report1;

            // Show the CrystalReportViewer
            crystalReportViewer.ShowDialog();*/
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ManageCLO newa = new ManageCLO();
            newa.WindowState = FormWindowState.Maximized;
            newa.Show();
            Visible = false;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ManageAssesment man = new ManageAssesment();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;
        }
    }

}

