﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace database_mids_project
{
    public partial class AddStudent2 : Form
    {
        public AddStudent2()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }

        private void student_studentData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void student_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void student_addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string rollNumber = regno.Text;
                if (!IsValidRollNumberFormat(rollNumber))
                {
                    errorProvider1.SetError(regno, "Invalid roll number format. Please use the format YYYY-Department-RollNo (e.g. 2023-CS-26).");
                    return;
                }
                else
                {
                    errorProvider1.SetError(regno, "");
                }
                string firstName = firstname.Text.Trim();
                if (!IsValidNameFormat(firstName))
                {
                    errorProvider2.SetError(firstname, "Invalid name format. Please use only letters and start with a capital letter.");
                    return;
                }
                else
                {
                    errorProvider2.SetError(firstname, "");
                }
                string lastName = lastname.Text.Trim();
                if (!IsValidNameFormat(lastName))
                {
                    errorProvider3.SetError(lastname, "Invalid name format. Please use only letters and start with a capital letter.");
                    return;
                }
                else
                {
                    errorProvider3.SetError(lastname, "");
                }
                string contact = contactno.Text.Trim();
                if (!IsValidContact(contact))
                {
                    errorProvider4.SetError(contactno, "Invalid contact number. Please enter 11 digits.");
                    return;
                }
                else
                {
                    errorProvider4.SetError(contactno, "");
                }

                string emails = email.Text.Trim();
                if (!IsValidEmail(emails))
                {
                    errorProvider5.SetError(email, "Invalid email address.");
                    return;
                }
                else
                {
                    errorProvider5.SetError(email, "");
                }
                if (status.SelectedItem == null)
                {
                    errorProvider6.SetError(status, "Please select from the list below.");
                    return;
                }


                save();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Following error occured :",ex.Message);
            }

        }
        private void save()
        {
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into student values(@Fname, @Lname,@Contact,@Email,@RegistrationNumber,@Status )", con);
            cmd.Parameters.AddWithValue("@Fname", firstname.Text);
            cmd.Parameters.AddWithValue("@Lname", lastname.Text);
            cmd.Parameters.AddWithValue("@RegistrationNumber", regno.Text);
            cmd.Parameters.AddWithValue("@Contact", contactno.Text);
            cmd.Parameters.AddWithValue("@Email", email.Text);
            int num = getnum();
            cmd.Parameters.AddWithValue("@Status", num);
            
       

            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Inserted!");
            printStudent();

        }
        private void printStudent()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "SELECT * FROM Student";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                studentData.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void hOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.WindowState = FormWindowState.Maximized;
            form1.Show();
            Visible = false;
        }

        private void AddStudent2_Load(object sender, EventArgs e)
        {
            printStudent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private bool IsValidRollNumberFormat(string rollNumber)
        {
            string pattern = @"^\d{4}-[A-Z]{2}-\d+$";
            return Regex.IsMatch(rollNumber, pattern);
        }
        private bool IsValidNameFormat(string name)
        {
            string pattern = @"^[A-Z][a-zA-Z]*$"; 
            return Regex.IsMatch(name, pattern);
        }
        private bool IsValidContact(string contact)
        {
            return Regex.IsMatch(contact, @"^\d{11}$");
        }

        private bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email, @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$");
        }
        private int getnum()
        {
            if (status.Text.Trim() == "Active")
            {
                return 5;
            }
            else
            {
                return 6;
            }
        }

        private void regno_TextChanged(object sender, EventArgs e)
        {

        }

        private void mANAGESTUDENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manage_students mana = new Manage_students();
            mana.WindowState = FormWindowState.Maximized;
            mana.Show();
            Visible = false;
        }

        private void mANAGERUBRICSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubrics manage = new ManageRubrics();
            manage.WindowState = FormWindowState.Maximized;
            manage.Show();
            Visible = false;
        }

        private void mANAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubricsLevel man = new ManageRubricsLevel();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void mARKEVALUATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MarkEvaluation markEvaluation = new MarkEvaluation();
            markEvaluation.WindowState = FormWindowState.Maximized;
            markEvaluation.Show();
            Visible = false;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ManageAssesment man = new ManageAssesment();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;
        }
    }
}
