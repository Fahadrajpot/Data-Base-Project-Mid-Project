﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace database_mids_project
{
    public partial class ManageRubricsLevel : Form
    {
        public ManageRubricsLevel()
        {
            InitializeComponent();
            fillCombo();
            WindowState = FormWindowState.Maximized;

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void student_addBtn_Click(object sender, EventArgs e)
        {
            if (!validateDetails(rubricdetials.Text))
            { return; }
            if (!validateRIdCombo())
            { return; }
            if (!validateLevelCombo())
            { return; }

            updateRubricLevel();
            fillCombo();
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void studentData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ManageRubricsLevel_Load(object sender, EventArgs e)
        {
            printRubricLevel();
            
        }
        private void printRubricLevel()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "SELECT * FROM RubricLevel";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                studentData.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }
        private void fillCombo()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "SELECT * FROM Rubric";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader["id"]);
                    comboBox1.Items.Add(id);

                }


                reader.Close();
                connection.Close();
            }
        }
        private bool validateDetails(string Details)
        {
            if (string.IsNullOrEmpty(Details.Trim()))
            {
                errorProvider2.SetError(rubricdetials, "Details are required");
                return false;
            }
            else
            {
                errorProvider2.SetError(rubricdetials, string.Empty);
            }

            return true;
        }
        private bool validateRIdCombo()
        {
            if (comboBox1.SelectedItem == null)
            {
                errorProvider1.SetError(comboBox1, "It cannot be empty.");
                return false;
            }
            else
            {
                errorProvider1.SetError(comboBox1, string.Empty);

            }
            return true;
        }
        private bool validateLevelCombo()
        {
            if (comboBox2.SelectedItem == null)
            {
                errorProvider3.SetError(comboBox2, "It cannot be empty.");
                return false;
            }
            else
            {
                errorProvider3.SetError(comboBox2, string.Empty);

            }
            return true;
        }
        private void reset()
        {
            rubricdetials.Clear();
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

        }
        private void addRubricLevel()
        {
            int number = giveNumber();
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO rubricLevel (RubricId, Details, MeasurementLevel) VALUES (@id, @Details, @level)", con);
                cmd.Parameters.AddWithValue("@id", comboBox1.Text);
                cmd.Parameters.AddWithValue("@Details", rubricdetials.Text);
                cmd.Parameters.AddWithValue("@level", number);
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("Successfully Inserted!");
            printRubricLevel();
            reset();
        }

        private void updateRubricLevel()
        {
            int number = giveNumber();
            int rID = Convert.ToInt32(studentData.SelectedRows[0].Cells[0].Value);
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            if (rID != 0)
            {
                using (SqlConnection con = new SqlConnection(constr))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE rubricLevel SET RubricId = @rid , Details = @Details, MeasurementLevel = @level WHERE Id = @id", con);
                    cmd.Parameters.AddWithValue("@rid", comboBox1.Text);
                    cmd.Parameters.AddWithValue("@Details", rubricdetials.Text);
                    cmd.Parameters.AddWithValue("@level", number);
                    cmd.Parameters.AddWithValue("@id", rID);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Successfully Updated!");
                printRubricLevel();
                reset();
            }
            else
            {
                return;
            }
        }

        private int giveNumber()
        {
            if (comboBox2.Text == "Unsatisfactory")
            {
                return 1;
            }
            else if (comboBox2.Text == "Fair")
            {
                return 2;
            }
            else if (comboBox2.Text == "Good")
            {
                return 3;
            }
            else 
            {
                return 4; 
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int rowIndex = Convert.ToInt32(studentData.SelectedRows[0].Cells[0].Value);
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string deleteQuery = "DELETE FROM rUBRIClEVEL WHERE id = @Id";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@Id", rowIndex);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();

                        MessageBox.Show("Successfully Deleted!");
                        printRubricLevel();

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error: " + ex.Message);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (!validateDetails(rubricdetials.Text))
            { return; }
            if (!validateRIdCombo())
            { return; }
            if (!validateLevelCombo())
            { return; }

            addRubricLevel();
            fillCombo();
        }

        private void mANAGESTUDENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manage_students mana = new Manage_students();
            mana.WindowState = FormWindowState.Maximized;

            mana.Show();
            Visible = false;
        }

        private void mANAGERUBRICSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubrics manage = new ManageRubrics();
            manage.WindowState = FormWindowState.Maximized;

            manage.Show();
            Visible = false;
        }

        private void mANAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubricsLevel man = new ManageRubricsLevel();
            man.WindowState = FormWindowState.Maximized;

            man.Show();
            Visible = false;
        }

        private void hOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.WindowState = FormWindowState.Maximized;

            form1.Show();
            Visible = false;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void mARKEVALUATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MarkEvaluation markEvaluation = new MarkEvaluation();
            markEvaluation.WindowState = FormWindowState.Maximized;
            markEvaluation.Show();
            Visible = false;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ManageCLO newa = new ManageCLO();
            newa.WindowState = FormWindowState.Maximized;
            newa.Show();
            Visible = false;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ManageAssesment man = new ManageAssesment();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
