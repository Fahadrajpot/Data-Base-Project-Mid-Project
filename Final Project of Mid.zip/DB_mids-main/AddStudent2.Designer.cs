﻿namespace database_mids_project
{
    partial class AddStudent2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.email = new System.Windows.Forms.TextBox();
            this.contactno = new System.Windows.Forms.TextBox();
            this.status = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.student_addBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.regno = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lastname = new System.Windows.Forms.TextBox();
            this.label = new System.Windows.Forms.Label();
            this.firstname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.hOMEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGESTUDENTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGERUBRICSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mARKEVALUATIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider5 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider6 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.studentData = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentData)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.email);
            this.panel2.Controls.Add(this.contactno);
            this.panel2.Controls.Add(this.status);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.student_addBtn);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.regno);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.lastname);
            this.panel2.Controls.Add(this.label);
            this.panel2.Controls.Add(this.firstname);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(274, 536);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1276, 351);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(468, 129);
            this.email.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.email.Multiline = true;
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(214, 36);
            this.email.TabIndex = 21;
            // 
            // contactno
            // 
            this.contactno.Location = new System.Drawing.Point(863, 129);
            this.contactno.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.contactno.Multiline = true;
            this.contactno.Name = "contactno";
            this.contactno.Size = new System.Drawing.Size(214, 36);
            this.contactno.TabIndex = 20;
            // 
            // status
            // 
            this.status.FormattingEnabled = true;
            this.status.Items.AddRange(new object[] {
            "Active",
            "NotActive"});
            this.status.Location = new System.Drawing.Point(863, 38);
            this.status.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(214, 28);
            this.status.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(757, 41);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 20);
            this.label8.TabIndex = 18;
            this.label8.Text = "Status:";
            // 
            // student_addBtn
            // 
            this.student_addBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.student_addBtn.FlatAppearance.BorderSize = 0;
            this.student_addBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.student_addBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.student_addBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.student_addBtn.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.student_addBtn.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.student_addBtn.Location = new System.Drawing.Point(566, 272);
            this.student_addBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.student_addBtn.Name = "student_addBtn";
            this.student_addBtn.Size = new System.Drawing.Size(153, 54);
            this.student_addBtn.TabIndex = 14;
            this.student_addBtn.Text = "Add";
            this.student_addBtn.UseVisualStyleBackColor = false;
            this.student_addBtn.Click += new System.EventHandler(this.student_addBtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(402, 132);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "Email";
            // 
            // regno
            // 
            this.regno.Location = new System.Drawing.Point(468, 32);
            this.regno.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.regno.Multiline = true;
            this.regno.Name = "regno";
            this.regno.Size = new System.Drawing.Size(214, 36);
            this.regno.TabIndex = 7;
            this.regno.TextChanged += new System.EventHandler(this.regno_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(387, 41);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Reg No";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(757, 146);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Contact No";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // lastname
            // 
            this.lastname.Location = new System.Drawing.Point(120, 129);
            this.lastname.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lastname.Multiline = true;
            this.lastname.Name = "lastname";
            this.lastname.Size = new System.Drawing.Size(214, 36);
            this.lastname.TabIndex = 3;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(30, 132);
            this.label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(86, 20);
            this.label.TabIndex = 2;
            this.label.Text = "Last Name";
            // 
            // firstname
            // 
            this.firstname.Location = new System.Drawing.Point(120, 32);
            this.firstname.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.firstname.Multiline = true;
            this.firstname.Name = "firstname";
            this.firstname.Size = new System.Drawing.Size(214, 36);
            this.firstname.TabIndex = 1;
            this.firstname.TextChanged += new System.EventHandler(this.student_id_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 41);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "First Name";
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuStrip2.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip2.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hOMEToolStripMenuItem,
            this.mANAGESTUDENTSToolStripMenuItem,
            this.mANAGERUBRICSToolStripMenuItem,
            this.mANAGEToolStripMenuItem,
            this.mARKEVALUATIONToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.menuStrip2.Size = new System.Drawing.Size(1825, 68);
            this.menuStrip2.TabIndex = 13;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // hOMEToolStripMenuItem
            // 
            this.hOMEToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.hOMEToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.hOMEToolStripMenuItem.Name = "hOMEToolStripMenuItem";
            this.hOMEToolStripMenuItem.Size = new System.Drawing.Size(104, 50);
            this.hOMEToolStripMenuItem.Text = "HOME";
            this.hOMEToolStripMenuItem.Click += new System.EventHandler(this.hOMEToolStripMenuItem_Click);
            // 
            // mANAGESTUDENTSToolStripMenuItem
            // 
            this.mANAGESTUDENTSToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGESTUDENTSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGESTUDENTSToolStripMenuItem.Name = "mANAGESTUDENTSToolStripMenuItem";
            this.mANAGESTUDENTSToolStripMenuItem.Padding = new System.Windows.Forms.Padding(7);
            this.mANAGESTUDENTSToolStripMenuItem.Size = new System.Drawing.Size(274, 50);
            this.mANAGESTUDENTSToolStripMenuItem.Text = "MANAGE STUDENTS";
            this.mANAGESTUDENTSToolStripMenuItem.Click += new System.EventHandler(this.mANAGESTUDENTSToolStripMenuItem_Click);
            // 
            // mANAGERUBRICSToolStripMenuItem
            // 
            this.mANAGERUBRICSToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGERUBRICSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGERUBRICSToolStripMenuItem.Name = "mANAGERUBRICSToolStripMenuItem";
            this.mANAGERUBRICSToolStripMenuItem.Size = new System.Drawing.Size(250, 50);
            this.mANAGERUBRICSToolStripMenuItem.Text = "MANAGE RUBRICS";
            this.mANAGERUBRICSToolStripMenuItem.Click += new System.EventHandler(this.mANAGERUBRICSToolStripMenuItem_Click);
            // 
            // mANAGEToolStripMenuItem
            // 
            this.mANAGEToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGEToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGEToolStripMenuItem.Name = "mANAGEToolStripMenuItem";
            this.mANAGEToolStripMenuItem.Size = new System.Drawing.Size(333, 50);
            this.mANAGEToolStripMenuItem.Text = "MANAGE RUBRICS LEVEL ";
            this.mANAGEToolStripMenuItem.Click += new System.EventHandler(this.mANAGEToolStripMenuItem_Click);
            // 
            // mARKEVALUATIONToolStripMenuItem
            // 
            this.mARKEVALUATIONToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mARKEVALUATIONToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mARKEVALUATIONToolStripMenuItem.Name = "mARKEVALUATIONToolStripMenuItem";
            this.mARKEVALUATIONToolStripMenuItem.Size = new System.Drawing.Size(269, 50);
            this.mARKEVALUATIONToolStripMenuItem.Text = "MARK EVALUATION";
            this.mARKEVALUATIONToolStripMenuItem.Click += new System.EventHandler(this.mARKEVALUATIONToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(204, 50);
            this.toolStripMenuItem1.Text = "MANAGE CLOs";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(290, 50);
            this.toolStripMenuItem2.Text = "MANAGE ASSESMENT";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // errorProvider5
            // 
            this.errorProvider5.ContainerControl = this;
            // 
            // errorProvider6
            // 
            this.errorProvider6.ContainerControl = this;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BackgroundImage = global::database_mids_project.Properties.Resources.city_growth_483x335_1;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.studentData);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(274, 81);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1276, 444);
            this.panel1.TabIndex = 4;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // studentData
            // 
            this.studentData.AllowUserToAddRows = false;
            this.studentData.AllowUserToDeleteRows = false;
            this.studentData.BackgroundColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(87)))), ((int)(((byte)(122)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.studentData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.studentData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.studentData.EnableHeadersVisualStyles = false;
            this.studentData.Location = new System.Drawing.Point(30, 72);
            this.studentData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.studentData.Name = "studentData";
            this.studentData.ReadOnly = true;
            this.studentData.RowHeadersVisible = false;
            this.studentData.RowHeadersWidth = 51;
            this.studentData.Size = new System.Drawing.Size(1215, 345);
            this.studentData.TabIndex = 1;
            this.studentData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.student_studentData_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(24, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student\'s Data";
            // 
            // AddStudent2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::database_mids_project.Properties.Resources._64e01bf1f7dbd9099e249e9c3247fdbb9a46b4b1_1280x7203;
            this.ClientSize = new System.Drawing.Size(1825, 919);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "AddStudent2";
            this.Text = "AddStudent2";
            this.Load += new System.EventHandler(this.AddStudent2_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox status;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button student_addBtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox regno;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox lastname;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.TextBox firstname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView studentData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem hOMEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGESTUDENTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGERUBRICSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mARKEVALUATIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.TextBox contactno;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ErrorProvider errorProvider5;
        private System.Windows.Forms.ErrorProvider errorProvider6;
    }
}