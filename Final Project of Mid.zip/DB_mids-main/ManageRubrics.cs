﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace database_mids_project
{
    public partial class ManageRubrics : Form
    {
        public ManageRubrics()
        {
            WindowState = FormWindowState.Maximized;

            InitializeComponent();
            fillComboCLO();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void hOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.WindowState = FormWindowState.Maximized;

            form1.Show();
            Visible = false;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void ManageRubrics_Load(object sender, EventArgs e)
        {
            Print_Rubrics();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (!validateCLOCombo())
            { return; }

            if (!validateDetails(Details_Box.Text))
            {
                return;
            }
            if (!ValidateId(RubricIdBox.Text))
            {
                return;
            }

            AddRubric();
        }
        private void Print_Rubrics()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "SELECT * FROM Rubric";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                Rubric_dATA.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void student_addBtn_Click(object sender, EventArgs e)
        {
            if (!validateCLOCombo())
            { return; }

            if (!validateDetails(Details_Box.Text))
            {
                return;
            }
            if (!Empty(RubricIdBox.Text))
            {
                return;
            }


            modifyRubic();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                int rowIndex = Convert.ToInt32(Rubric_dATA.SelectedRows[0].Cells[0].Value);
                string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";

                string deleteQuery = "DELETE FROM rubric WHERE id = @RId";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                    {
                        command.Parameters.AddWithValue("@RId", rowIndex);


                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                        MessageBox.Show("Successfully Deleted!");
                        printRubric();



                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void printRubric()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "SELECT * FROM rubric";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                Rubric_dATA.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }
        private void fillComboCLO()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "SELECT * FROM CLO";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    comboBox1.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }
        private int getCLOid()
        {
            int CLOId = -1;
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from Clo where name = @name", con);
            cmd.Parameters.AddWithValue("@name", comboBox1.Text);

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                CLOId = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return CLOId;
        }
        private void AddRubric()
        {
            int number = getCLOid();
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO rubric (Id, Details, CLoId) VALUES (@id, @Details, @CLoId)", con);
                cmd.Parameters.AddWithValue("@id", RubricIdBox.Text);
                cmd.Parameters.AddWithValue("@Details", Details_Box.Text);
                if (number != -1)
                {
                    cmd.Parameters.AddWithValue("@CLoId", number);
                }
                else
                {
                    return;
                }
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("Successfully Inserted!");
            printRubric();
            reset();

        }

        private void modifyRubic()
        {
            int rID = Convert.ToInt32(Rubric_dATA.SelectedRows[0].Cells[0].Value);
            int number = getCLOid();
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("UPDATE rubric SET  id = @id ,Details = @Details, CLoId = @CLoId WHERE Id = @id", con);
                cmd.Parameters.AddWithValue("@id", rID);
                cmd.Parameters.AddWithValue("@Details", Details_Box.Text);
                if (number != -1)
                {
                    cmd.Parameters.AddWithValue("@CLoId", number);
                }
                else
                {
                    return;
                }
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("Successfully Updated!");
            printRubric();
            reset();
        }

        private bool validateDetails(string Details)
        {
            if (string.IsNullOrEmpty(Details.Trim()))
            {
                errorProvider2.SetError(Details_Box, "Details are required");
                return false;
            }
            else
            {
                errorProvider2.SetError(Details_Box, string.Empty);
            }

            return true;
        }

        private bool validateCLOCombo()
        {
            if (comboBox1.SelectedItem == null)
            {
                errorProvider1.SetError(comboBox1, "It cannot be empty.");
                return false;
            }
            else
            {
                errorProvider1.SetError(comboBox1, string.Empty);

            }
            return true;
        }

        private bool ValidateId(string total)
        {
            int number;

            if (string.IsNullOrWhiteSpace(total) || !int.TryParse(total, out number))
            {
                errorProvider3.SetError(RubricIdBox, "It is required and it should be an integer");
                return false;
            }
            else
            {
                errorProvider3.SetError(RubricIdBox, string.Empty);
                return true;
            }
        }
        private void reset()
        {
            RubricIdBox.Clear();
            Details_Box.Clear();
        }

        private bool Empty(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                errorProvider3.SetError(RubricIdBox, string.Empty);
                return true;
            }
            errorProvider3.SetError(RubricIdBox, "The id box should be empty while Modifying.");
            return false;

        }

        private void Rubric_dATA_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void mANAGESTUDENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manage_students mana = new Manage_students();
            mana.WindowState = FormWindowState.Maximized;

            mana.Show();
            Visible = false;
        }

        private void mANAGERUBRICSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubrics manage = new ManageRubrics();
            manage.WindowState = FormWindowState.Maximized;

            manage.Show();
            Visible = false;
        }

        private void mANAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubricsLevel man = new ManageRubricsLevel();
            man.WindowState = FormWindowState.Maximized;

            man.Show();
            Visible = false;
        }

        private void mARKEVALUATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MarkEvaluation markEvaluation = new MarkEvaluation();
            markEvaluation.WindowState = FormWindowState.Maximized;
            markEvaluation.Show();
            Visible = false;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ManageCLO newa = new ManageCLO();
            newa.WindowState = FormWindowState.Maximized;
            newa.Show();
            Visible = false;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ManageAssesment man = new ManageAssesment();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;
        }

        private void Details_Box_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
