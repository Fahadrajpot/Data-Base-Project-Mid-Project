﻿namespace database_mids_project
{
    partial class MarkEvaluation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.hOMEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGESTUDENTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGERUBRICSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mARKEVALUATIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.panel2 = new System.Windows.Forms.Panel();
            this.save = new System.Windows.Forms.Button();
            this.date = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.rubricdetails = new System.Windows.Forms.Label();
            this.rubriclevel = new System.Windows.Forms.Label();
            this.component = new System.Windows.Forms.Label();
            this.rubricid = new System.Windows.Forms.Label();
            this.studentcombo = new System.Windows.Forms.ComboBox();
            this.componentcombo = new System.Windows.Forms.ComboBox();
            this.rubricdetailcombo = new System.Windows.Forms.ComboBox();
            this.rubriclevelcombo = new System.Windows.Forms.ComboBox();
            this.rubricidcombo = new System.Windows.Forms.ComboBox();
            this.assessmentcombo = new System.Windows.Forms.ComboBox();
            this.assessment = new System.Windows.Forms.Label();
            this.student = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.studentData = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider5 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider6 = new System.Windows.Forms.ErrorProvider(this.components);
            this.menuStrip2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuStrip2.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip2.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hOMEToolStripMenuItem,
            this.mANAGESTUDENTSToolStripMenuItem,
            this.mANAGERUBRICSToolStripMenuItem,
            this.mANAGEToolStripMenuItem,
            this.mARKEVALUATIONToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.menuStrip2.Size = new System.Drawing.Size(1692, 68);
            this.menuStrip2.TabIndex = 37;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // hOMEToolStripMenuItem
            // 
            this.hOMEToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.hOMEToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.hOMEToolStripMenuItem.Name = "hOMEToolStripMenuItem";
            this.hOMEToolStripMenuItem.Size = new System.Drawing.Size(104, 50);
            this.hOMEToolStripMenuItem.Text = "HOME";
            this.hOMEToolStripMenuItem.Click += new System.EventHandler(this.hOMEToolStripMenuItem_Click_1);
            // 
            // mANAGESTUDENTSToolStripMenuItem
            // 
            this.mANAGESTUDENTSToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGESTUDENTSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGESTUDENTSToolStripMenuItem.Name = "mANAGESTUDENTSToolStripMenuItem";
            this.mANAGESTUDENTSToolStripMenuItem.Padding = new System.Windows.Forms.Padding(7);
            this.mANAGESTUDENTSToolStripMenuItem.Size = new System.Drawing.Size(274, 50);
            this.mANAGESTUDENTSToolStripMenuItem.Text = "MANAGE STUDENTS";
            this.mANAGESTUDENTSToolStripMenuItem.Click += new System.EventHandler(this.mANAGESTUDENTSToolStripMenuItem_Click);
            // 
            // mANAGERUBRICSToolStripMenuItem
            // 
            this.mANAGERUBRICSToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGERUBRICSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGERUBRICSToolStripMenuItem.Name = "mANAGERUBRICSToolStripMenuItem";
            this.mANAGERUBRICSToolStripMenuItem.Size = new System.Drawing.Size(250, 50);
            this.mANAGERUBRICSToolStripMenuItem.Text = "MANAGE RUBRICS";
            this.mANAGERUBRICSToolStripMenuItem.Click += new System.EventHandler(this.mANAGERUBRICSToolStripMenuItem_Click);
            // 
            // mANAGEToolStripMenuItem
            // 
            this.mANAGEToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGEToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGEToolStripMenuItem.Name = "mANAGEToolStripMenuItem";
            this.mANAGEToolStripMenuItem.Size = new System.Drawing.Size(333, 50);
            this.mANAGEToolStripMenuItem.Text = "MANAGE RUBRICS LEVEL ";
            this.mANAGEToolStripMenuItem.Click += new System.EventHandler(this.mANAGEToolStripMenuItem_Click);
            // 
            // mARKEVALUATIONToolStripMenuItem
            // 
            this.mARKEVALUATIONToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mARKEVALUATIONToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mARKEVALUATIONToolStripMenuItem.Name = "mARKEVALUATIONToolStripMenuItem";
            this.mARKEVALUATIONToolStripMenuItem.Size = new System.Drawing.Size(269, 50);
            this.mARKEVALUATIONToolStripMenuItem.Text = "MARK EVALUATION";
            this.mARKEVALUATIONToolStripMenuItem.Click += new System.EventHandler(this.mARKEVALUATIONToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(204, 50);
            this.toolStripMenuItem1.Text = "MANAGE CLOs";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(290, 50);
            this.toolStripMenuItem2.Text = "MANAGE ASSESMENT";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.save);
            this.panel2.Controls.Add(this.date);
            this.panel2.Controls.Add(this.dateTimePicker1);
            this.panel2.Controls.Add(this.rubricdetails);
            this.panel2.Controls.Add(this.rubriclevel);
            this.panel2.Controls.Add(this.component);
            this.panel2.Controls.Add(this.rubricid);
            this.panel2.Controls.Add(this.studentcombo);
            this.panel2.Controls.Add(this.componentcombo);
            this.panel2.Controls.Add(this.rubricdetailcombo);
            this.panel2.Controls.Add(this.rubriclevelcombo);
            this.panel2.Controls.Add(this.rubricidcombo);
            this.panel2.Controls.Add(this.assessmentcombo);
            this.panel2.Controls.Add(this.assessment);
            this.panel2.Controls.Add(this.student);
            this.panel2.Location = new System.Drawing.Point(326, 97);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1027, 351);
            this.panel2.TabIndex = 38;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // save
            // 
            this.save.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.save.FlatAppearance.BorderSize = 0;
            this.save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.save.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.save.Location = new System.Drawing.Point(440, 271);
            this.save.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(153, 54);
            this.save.TabIndex = 42;
            this.save.Text = "Evaluate";
            this.save.UseVisualStyleBackColor = false;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // date
            // 
            this.date.AutoSize = true;
            this.date.Location = new System.Drawing.Point(365, 217);
            this.date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(44, 20);
            this.date.TabIndex = 41;
            this.date.Text = "Date";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(440, 212);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(224, 26);
            this.dateTimePicker1.TabIndex = 40;
            // 
            // rubricdetails
            // 
            this.rubricdetails.AutoSize = true;
            this.rubricdetails.Location = new System.Drawing.Point(30, 136);
            this.rubricdetails.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.rubricdetails.Name = "rubricdetails";
            this.rubricdetails.Size = new System.Drawing.Size(108, 20);
            this.rubricdetails.TabIndex = 33;
            this.rubricdetails.Text = "Rubric Details";
            // 
            // rubriclevel
            // 
            this.rubriclevel.AutoSize = true;
            this.rubriclevel.Location = new System.Drawing.Point(381, 136);
            this.rubriclevel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.rubriclevel.Name = "rubriclevel";
            this.rubriclevel.Size = new System.Drawing.Size(90, 20);
            this.rubriclevel.TabIndex = 32;
            this.rubriclevel.Text = "Rubric level";
            // 
            // component
            // 
            this.component.AutoSize = true;
            this.component.Location = new System.Drawing.Point(717, 41);
            this.component.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.component.Name = "component";
            this.component.Size = new System.Drawing.Size(92, 20);
            this.component.TabIndex = 31;
            this.component.Text = "Component";
            // 
            // rubricid
            // 
            this.rubricid.AutoSize = true;
            this.rubricid.Location = new System.Drawing.Point(717, 135);
            this.rubricid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.rubricid.Name = "rubricid";
            this.rubricid.Size = new System.Drawing.Size(76, 20);
            this.rubricid.TabIndex = 30;
            this.rubricid.Text = "Rubric ID";
            // 
            // studentcombo
            // 
            this.studentcombo.FormattingEnabled = true;
            this.studentcombo.Location = new System.Drawing.Point(145, 38);
            this.studentcombo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.studentcombo.Name = "studentcombo";
            this.studentcombo.Size = new System.Drawing.Size(175, 28);
            this.studentcombo.TabIndex = 28;
            // 
            // componentcombo
            // 
            this.componentcombo.FormattingEnabled = true;
            this.componentcombo.Location = new System.Drawing.Point(813, 41);
            this.componentcombo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.componentcombo.Name = "componentcombo";
            this.componentcombo.Size = new System.Drawing.Size(175, 28);
            this.componentcombo.TabIndex = 27;
            // 
            // rubricdetailcombo
            // 
            this.rubricdetailcombo.FormattingEnabled = true;
            this.rubricdetailcombo.Location = new System.Drawing.Point(145, 136);
            this.rubricdetailcombo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rubricdetailcombo.Name = "rubricdetailcombo";
            this.rubricdetailcombo.Size = new System.Drawing.Size(175, 28);
            this.rubricdetailcombo.TabIndex = 26;
            // 
            // rubriclevelcombo
            // 
            this.rubriclevelcombo.FormattingEnabled = true;
            this.rubriclevelcombo.Items.AddRange(new object[] {
            "Exceptional",
            "Good",
            "Fair",
            "Unsatisfactory"});
            this.rubriclevelcombo.Location = new System.Drawing.Point(477, 136);
            this.rubriclevelcombo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rubriclevelcombo.Name = "rubriclevelcombo";
            this.rubriclevelcombo.Size = new System.Drawing.Size(175, 28);
            this.rubriclevelcombo.TabIndex = 25;
            // 
            // rubricidcombo
            // 
            this.rubricidcombo.FormattingEnabled = true;
            this.rubricidcombo.Location = new System.Drawing.Point(813, 136);
            this.rubricidcombo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rubricidcombo.Name = "rubricidcombo";
            this.rubricidcombo.Size = new System.Drawing.Size(175, 28);
            this.rubricidcombo.TabIndex = 24;
            // 
            // assessmentcombo
            // 
            this.assessmentcombo.FormattingEnabled = true;
            this.assessmentcombo.Location = new System.Drawing.Point(477, 38);
            this.assessmentcombo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.assessmentcombo.Name = "assessmentcombo";
            this.assessmentcombo.Size = new System.Drawing.Size(175, 28);
            this.assessmentcombo.TabIndex = 23;
            // 
            // assessment
            // 
            this.assessment.AutoSize = true;
            this.assessment.Location = new System.Drawing.Point(349, 41);
            this.assessment.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.assessment.Name = "assessment";
            this.assessment.Size = new System.Drawing.Size(97, 20);
            this.assessment.TabIndex = 6;
            this.assessment.Text = "Assessment";
            // 
            // student
            // 
            this.student.AutoSize = true;
            this.student.Location = new System.Drawing.Point(30, 41);
            this.student.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.student.Name = "student";
            this.student.Size = new System.Drawing.Size(66, 20);
            this.student.TabIndex = 0;
            this.student.Text = "Student";
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.studentData);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(207, 491);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1276, 444);
            this.panel1.TabIndex = 39;
            // 
            // studentData
            // 
            this.studentData.BackgroundColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.studentData.Location = new System.Drawing.Point(34, 85);
            this.studentData.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.studentData.Name = "studentData";
            this.studentData.RowHeadersWidth = 51;
            this.studentData.RowTemplate.Height = 24;
            this.studentData.Size = new System.Drawing.Size(1191, 334);
            this.studentData.TabIndex = 40;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(29, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Students Data";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // errorProvider5
            // 
            this.errorProvider5.ContainerControl = this;
            // 
            // errorProvider6
            // 
            this.errorProvider6.ContainerControl = this;
            // 
            // MarkEvaluation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::database_mids_project.Properties.Resources._64e01bf1f7dbd9099e249e9c3247fdbb9a46b4b1_1280x720;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1692, 962);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip2);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MarkEvaluation";
            this.Text = "MarkEvaluation";
            this.Load += new System.EventHandler(this.MarkEvaluation_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem hOMEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGESTUDENTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGERUBRICSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mARKEVALUATIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox assessmentcombo;
        private System.Windows.Forms.Label assessment;
        private System.Windows.Forms.Label student;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox studentcombo;
        private System.Windows.Forms.ComboBox componentcombo;
        private System.Windows.Forms.ComboBox rubricdetailcombo;
        private System.Windows.Forms.ComboBox rubriclevelcombo;
        private System.Windows.Forms.ComboBox rubricidcombo;
        private System.Windows.Forms.Label rubricdetails;
        private System.Windows.Forms.Label rubriclevel;
        private System.Windows.Forms.Label component;
        private System.Windows.Forms.Label rubricid;
        private System.Windows.Forms.Label date;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ErrorProvider errorProvider5;
        private System.Windows.Forms.ErrorProvider errorProvider6;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.DataGridView studentData;
    }
}