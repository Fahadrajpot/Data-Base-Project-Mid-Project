﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace database_mids_project
{
    public partial class AssessmentComponent : Form
    {
        public AssessmentComponent()
        {
            InitializeComponent();
            fillAssessmentCombo();
            fillRubricCombo();
            WindowState = FormWindowState.Maximized;

        }

        private void AssessmentComponent_Load(object sender, EventArgs e)
        {
            printAssessmentComponent();
        }
        private void printAssessmentComponent()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "SELECT * FROM assessmentcomponent";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                studentData.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }
        private void addAssessmentComp()
        {
            int aID = getAsssessmentId();
            int rID = getRubricId();

            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
           if (aID != -1 && rID != -1)
           {
                using (SqlConnection con = new SqlConnection(constr))
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO assessmentComponent (Name, RubricId, TotalMarks, DateCreated, DateUpdated, AssessmentId) VALUES (@name, @rid, @totalmarks, GetDate(), GetDate(), @aId)", con);
                    cmd.Parameters.AddWithValue("@name", inputname.Text);
                    cmd.Parameters.AddWithValue("@rId", rID);
                    cmd.Parameters.AddWithValue("@totalmarks", totalmarks.Text);
                    cmd.Parameters.AddWithValue("@aId", aID);

                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Successfully Inserted!");
                printAssessmentComponent();
                reset();
           }
           else
           {
                MessageBox.Show("Something cooked");
            }
        }
        private void ModifyAssessmentComp()
        {
            int ACID = Convert.ToInt32(studentData.SelectedRows[0].Cells[0].Value); // gets the id of selected row
            DateTime Date = Convert.ToDateTime(studentData.SelectedRows[0].Cells[4].Value); // gets the date from selected row
            int aID = Convert.ToInt32(studentData.SelectedRows[0].Cells[6].Value);
            int rID = Convert.ToInt32(studentData.SelectedRows[0].Cells[2].Value);


            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";


            if (aID != 0 && rID != 0 && ACID != 0 && Date != null)
            {
                using (SqlConnection con = new SqlConnection(constr))
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE assessmentComponent SET Name = @name, RubricId = @rId, TotalMarks = @totalmarks,DateCreated = @date,  DateUpdated = GetDate(), AssessmentId = @aId WHERE id = @id", con);
                    cmd.Parameters.AddWithValue("@name", inputname.Text);
                    cmd.Parameters.AddWithValue("@rId", rID);
                    cmd.Parameters.AddWithValue("@totalmarks", totalmarks.Text);
                    cmd.Parameters.AddWithValue("@date", Date);
                    cmd.Parameters.AddWithValue("@aId", aID);
                    cmd.Parameters.AddWithValue("@id", ACID);

                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Successfully Updated!");
                printAssessmentComponent();
                reset();
            }
            else
            {
                return;
            }


        }
        private void reset()
        {
            inputname.Clear();
            totalmarks.Clear();
            comboBox2.Items.Clear();
            comboBox3.Items.Clear();

        }

        private int getAsssessmentId()
        {
            int Id = -1;
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from assessment where title = @title", con);
            cmd.Parameters.AddWithValue("@title", comboBox2.Text);

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                Id = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return Id;
        }

        private int getRubricId()
        {
            int Id = -1;
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from rubric where details = @details", con);
            cmd.Parameters.AddWithValue("@details", comboBox3.Text);

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                Id = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return Id;
        }

        private bool validateAssessmentCombo()
        {
            if (comboBox2.SelectedItem == null)
            {
                errorProvider3.SetError(comboBox2, "It cannot be empty.");
                return false;
            }
            else
            {
                errorProvider3.SetError(comboBox2, string.Empty);

            }
            return true;
        }

        private bool validateRubricCombo()
        {
            if (comboBox3.SelectedItem == null)
            {
                errorProvider4.SetError(comboBox3, "It cannot be empty.");
                return false;
            }
            else
            {
                errorProvider4.SetError(comboBox3, string.Empty);

            }
            return true;
        }


        private bool validateName(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                errorProvider1.SetError(inputname, "This name is required.");
                return false;
            }
            else
            {
                errorProvider1.SetError(inputname, string.Empty);
                return true;
            }

        }

        private bool validateMarks(string marks)
        {
           
            if (!ContainsOnlyDigits(marks))
            {
                errorProvider2.SetError(totalmarks, "It is required and it should be an integer");
                return false;
            }
            else
            {
                errorProvider2.SetError(totalmarks, string.Empty);
                return true;

            }
        }
        private bool ContainsOnlyDigits(string input)
        {
            foreach (char c in input)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void fillAssessmentCombo()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "SELECT * FROM Assessment";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    comboBox2.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }


        private void fillRubricCombo()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "SELECT * FROM rubric";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    comboBox3.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int rowIndex = Convert.ToInt32(studentData.SelectedRows[0].Cells[0].Value);
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string deleteQuery = "DELETE FROM AssessmentComponent WHERE id = @Id";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@Id", rowIndex);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();

                        MessageBox.Show("Successfully Deleted!");
                        printAssessmentComponent();

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error: " + ex.Message);
                    }
                }
            }
        }

        private void student_addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (!validateName(inputname.Text))
                {
                    return;
                }
                if (!validateMarks(totalmarks.Text))
                {
                    return;
                }
                if (!validateAssessmentCombo())
                {
                    return;
                }
                if (!validateRubricCombo())
                {
                    return;
                }

                ModifyAssessmentComp();
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error: ",ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (!validateName(inputname.Text))
                {
                    return;
                }
                if (!validateMarks(totalmarks.Text))
                {
                    return;
                }
                if (!validateAssessmentCombo())
                {
                    return;
                }
                if (!validateRubricCombo())
                {
                    return;
                }

                addAssessmentComp();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void hOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.WindowState = FormWindowState.Maximized;
            form1.Show();
            Visible = false;
        }

        private void mANAGESTUDENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manage_students mana = new Manage_students();
            mana.WindowState = FormWindowState.Maximized;
            mana.Show();
            Visible = false;
        }

        private void mANAGERUBRICSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubrics manage = new ManageRubrics();
            manage.WindowState = FormWindowState.Maximized;
            manage.Show();
            Visible = false;
        }

        private void mANAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubricsLevel man = new ManageRubricsLevel();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;
        }

        private void mARKEVALUATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MarkEvaluation markEvaluation = new MarkEvaluation();
            markEvaluation.WindowState = FormWindowState.Maximized;
            markEvaluation.Show();
            Visible = false;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ManageCLO newa = new ManageCLO();
            newa.WindowState = FormWindowState.Maximized;
            newa.Show();
            Visible = false;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ManageAssesment man = new ManageAssesment();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;
        }
    }
}
