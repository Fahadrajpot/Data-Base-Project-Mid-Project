﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace database_mids_project
{
    public partial class ManageAssesment : Form
    {
        public ManageAssesment()
        {
            WindowState = FormWindowState.Maximized;

            InitializeComponent();
        }

        private void mANAGESTUDENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manage_students manage_ = new Manage_students();
            manage_.WindowState = FormWindowState.Maximized;

            manage_.Show();
            Visible = false;
        }
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void ManageAssesment_Load(object sender, EventArgs e)
        {
            printAssesments();
            MaximizeBox = false;
        }
        private void printAssesments()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "SELECT * FROM Assessment";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                dataGridView1.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           
        }

        private void hOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 ab= new Form1();
            ab.Show();
            Visible = false;

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void student_addBtn_Click(object sender, EventArgs e)
        {
            if (!IsValidTitleFormat(title.Text))
            {
                errorProvider1.SetError(title, "Invalid title name.First letter should be capital and all alphabets");
                return;
            }
            else
            {
                errorProvider1.SetError(title, "");
            }
            if (!IsInteger(marks.Text))
            {
                errorProvider2.SetError(marks, "Invalid input it should be integer.");
                return;
            }
            else
            {
                errorProvider2.SetError(marks, "");
            }
            if (!IsInteger(weight.Text))
            {
                errorProvider3.SetError(weight, "Invalid input it must consist of digits.");
                return;
            }
            else
            {
                errorProvider3.SetError(weight, "");
            }
            Addbutton();
        }
        private void Addbutton ()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "INSERT INTO Assessment Values(@Title,GetDate(),@TotalMarks,@TotalWeightage );";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Title", title.Text);
            command.Parameters.AddWithValue("@TotalMarks", marks.Text);
            command.Parameters.AddWithValue("@TotalWeightage", weight.Text);

            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Added Successfully");
            printAssesments();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (!IsValidTitleFormat(title.Text))
            {
                errorProvider1.SetError(title, "Invalid title name.First letter should be capital and all alphabets");
                return;
            }
            else
            {
                errorProvider1.SetError(title, "");
            }
            if (!IsInteger(marks.Text))
            {
                errorProvider2.SetError(marks, "Invalid input it should be integer.");
                return;
            }
            else
            {
                errorProvider2.SetError(marks, "");
            }
            if (!IsInteger(weight.Text))
            {
                errorProvider3.SetError(weight, "Invalid input it must consist of digits.");
                return;
            }
            else
            {
                errorProvider3.SetError(weight, "");
            }
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            int ID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);

            con.Open();
            string titles = title.Text;
            string weght = weight .Text;
            string mark = marks.Text;
            SqlCommand cmd = new SqlCommand("update Assessment set Title = '" + titles + "',DateCreated = GetDate(),TotalMarks = "+mark+",TotalWeightage = " +weght+ " Where ID = "+ID+";", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Updated!");
            printAssesments();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete from Assessment where ID = " + ID + ";", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Deleted!");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private bool IsValidTitleFormat(string title)
        {
            string pattern = @"^[A-Z][a-zA-Z]*$";
            return Regex.IsMatch(title, pattern);
        }
        static bool IsInteger(string input)
        {
            int result;
            return int.TryParse(input, out result);
        }

        private void mANAGERUBRICSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubrics manageRubrics = new ManageRubrics();
            manageRubrics.WindowState = FormWindowState.Maximized;

            manageRubrics.Show();
            Visible = false;
        }

        private void mANAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubricsLevel man = new ManageRubricsLevel();
            man.WindowState = FormWindowState.Maximized;

            man.Show();
            Visible = false;
        }

        private void mARKEVALUATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MarkEvaluation markEvaluation = new MarkEvaluation();

            markEvaluation.WindowState = FormWindowState.Maximized;

            markEvaluation.Show();
            Visible = false;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ManageCLO newa = new ManageCLO();
            newa.WindowState = FormWindowState.Maximized;
            newa.Show();
            Visible = false;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ManageAssesment man = new ManageAssesment();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;
        }
    }
}
