﻿namespace database_mids_project
{
    partial class Delete_student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.hOMEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGESTUDENTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGERUBRICSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mARKEVALUATIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Font = new System.Drawing.Font("Stencil", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label6.Location = new System.Drawing.Point(515, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(592, 33);
            this.label6.TabIndex = 38;
            this.label6.Text = "SELECT THE STUDENT YOU WANT TO DELETE";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(308, 174);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1045, 542);
            this.dataGridView1.TabIndex = 37;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Stencil", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.Location = new System.Drawing.Point(748, 822);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(170, 79);
            this.button1.TabIndex = 40;
            this.button1.Text = "DELETE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // hOMEToolStripMenuItem
            // 
            this.hOMEToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.hOMEToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.hOMEToolStripMenuItem.Name = "hOMEToolStripMenuItem";
            this.hOMEToolStripMenuItem.Size = new System.Drawing.Size(104, 50);
            this.hOMEToolStripMenuItem.Text = "HOME";
            this.hOMEToolStripMenuItem.Click += new System.EventHandler(this.hOMEToolStripMenuItem_Click);
            // 
            // mANAGESTUDENTSToolStripMenuItem
            // 
            this.mANAGESTUDENTSToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGESTUDENTSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGESTUDENTSToolStripMenuItem.Name = "mANAGESTUDENTSToolStripMenuItem";
            this.mANAGESTUDENTSToolStripMenuItem.Padding = new System.Windows.Forms.Padding(7);
            this.mANAGESTUDENTSToolStripMenuItem.Size = new System.Drawing.Size(274, 50);
            this.mANAGESTUDENTSToolStripMenuItem.Text = "MANAGE STUDENTS";
            this.mANAGESTUDENTSToolStripMenuItem.Click += new System.EventHandler(this.mANAGESTUDENTSToolStripMenuItem_Click);
            // 
            // mANAGERUBRICSToolStripMenuItem
            // 
            this.mANAGERUBRICSToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGERUBRICSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGERUBRICSToolStripMenuItem.Name = "mANAGERUBRICSToolStripMenuItem";
            this.mANAGERUBRICSToolStripMenuItem.Size = new System.Drawing.Size(250, 50);
            this.mANAGERUBRICSToolStripMenuItem.Text = "MANAGE RUBRICS";
            this.mANAGERUBRICSToolStripMenuItem.Click += new System.EventHandler(this.mANAGERUBRICSToolStripMenuItem_Click);
            // 
            // mANAGEToolStripMenuItem
            // 
            this.mANAGEToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGEToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGEToolStripMenuItem.Name = "mANAGEToolStripMenuItem";
            this.mANAGEToolStripMenuItem.Size = new System.Drawing.Size(333, 50);
            this.mANAGEToolStripMenuItem.Text = "MANAGE RUBRICS LEVEL ";
            this.mANAGEToolStripMenuItem.Click += new System.EventHandler(this.mANAGEToolStripMenuItem_Click);
            // 
            // mARKEVALUATIONToolStripMenuItem
            // 
            this.mARKEVALUATIONToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mARKEVALUATIONToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mARKEVALUATIONToolStripMenuItem.Name = "mARKEVALUATIONToolStripMenuItem";
            this.mARKEVALUATIONToolStripMenuItem.Size = new System.Drawing.Size(269, 50);
            this.mARKEVALUATIONToolStripMenuItem.Text = "MARK EVALUATION";
            this.mARKEVALUATIONToolStripMenuItem.Click += new System.EventHandler(this.mARKEVALUATIONToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(204, 50);
            this.toolStripMenuItem1.Text = "MANAGE CLOs";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(290, 50);
            this.toolStripMenuItem2.Text = "MANAGE ASSESMENT";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuStrip2.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip2.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hOMEToolStripMenuItem,
            this.mANAGESTUDENTSToolStripMenuItem,
            this.mANAGERUBRICSToolStripMenuItem,
            this.mANAGEToolStripMenuItem,
            this.mARKEVALUATIONToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.menuStrip2.Size = new System.Drawing.Size(1708, 68);
            this.menuStrip2.TabIndex = 39;
            this.menuStrip2.Text = "menuStrip2";
            this.menuStrip2.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip2_ItemClicked);
            // 
            // Delete_student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImage = global::database_mids_project.Properties.Resources._64e01bf1f7dbd9099e249e9c3247fdbb9a46b4b1_1280x7201;
            this.ClientSize = new System.Drawing.Size(1708, 1016);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Delete_student";
            this.Text = "Delete_student";
            this.Load += new System.EventHandler(this.Delete_student_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem hOMEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGESTUDENTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGERUBRICSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mARKEVALUATIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.MenuStrip menuStrip2;
    }
}