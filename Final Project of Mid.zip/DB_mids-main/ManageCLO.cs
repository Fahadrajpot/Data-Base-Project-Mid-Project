﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace database_mids_project
{
    public partial class ManageCLO : Form
    {
        public ManageCLO()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void hOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.WindowState = FormWindowState.Maximized;
            form1.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string var = textBox1.Text;
            SqlCommand cmd = new SqlCommand("Update Clo Set name = '"+var+"',DateUpdated = GetDate() Where Id ="+ID+";",con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Updated!");

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Clo values(@name, GetDate(),GetDate())", con);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Inserted!");
            printclo();
        }
        private void printclo()
        {
            string connectionString = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            string query = "SELECT * FROM Clo";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                dataGridView1.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }

        private void ManageCLO_Load(object sender, EventArgs e)
        {
            printclo();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete from Clo where ID ="+ID+";", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Updated!");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void student_addBtn_Click(object sender, EventArgs e)
        {
            if (!IsValidNameFormat(textBox1.Text))
            {
                errorProvider1.SetError(textBox1, "Invalid name format. Please use only letters and start with a capital letter.");
                return;
            }
            else
            {
                errorProvider1.SetError(textBox1, "");
            }
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Clo values(@name, GetDate(),GetDate())", con);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);




            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Inserted!");
            printclo();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string var = textBox1.Text;
            SqlCommand cmd = new SqlCommand("Update Clo Set name = '" + var + "',DateUpdated = GetDate() Where Id =" + ID + ";", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Updated!");
            printclo();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete from Clo where ID =" + ID + ";", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Deleted!");
            printclo();
        }

        private void mANAGESTUDENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manage_students mana = new Manage_students();
            mana.WindowState = FormWindowState.Maximized;

            mana.Show();
            Visible = false;
        }

        private void mANAGERUBRICSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubrics manage = new ManageRubrics();
            manage.WindowState = FormWindowState.Maximized;

            manage.Show();
            Visible = false;
        }

        private void mANAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubricsLevel man = new ManageRubricsLevel();
            man.WindowState = FormWindowState.Maximized;

            man.Show();
            Visible = false;
        }
        private bool IsValidNameFormat(string name)
        {
            string pattern = @"^[A-Z][a-zA-Z]*$";
            return Regex.IsMatch(name, pattern);
        }

        private void mARKEVALUATIONToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MarkEvaluation markEvaluation = new MarkEvaluation();
            markEvaluation.WindowState = FormWindowState.Maximized;
            markEvaluation.Show();
            Visible = false;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ManageCLO newa = new ManageCLO();
            newa.WindowState = FormWindowState.Maximized;
            newa.Show();
            Visible = false;
        }
    }
}
