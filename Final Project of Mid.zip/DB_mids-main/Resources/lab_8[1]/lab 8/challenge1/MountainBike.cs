﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class MountainBike:Bicycle
    {
        private int seatHeight;

        public MountainBike(int seatHeight,int cadence, int grar, int speed) : base(cadence, grar, speed)
        {
            this.seatHeight = seatHeight;
     

        }
        public void SetSeatHeight(int seatHeight)
        {
            this.seatHeight = seatHeight;
        }
       
    }
}
