﻿namespace database_mids_project
{
    partial class ManageAssesment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.hOMEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGESTUDENTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGERUBRICSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mANAGEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mARKEVALUATIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.marks = new System.Windows.Forms.TextBox();
            this.title = new System.Windows.Forms.TextBox();
            this.weight = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Update_Assesment = new System.Windows.Forms.Button();
            this.Delete_Assesment = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.Add_Assesment = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.menuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuStrip2.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip2.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hOMEToolStripMenuItem,
            this.mANAGESTUDENTSToolStripMenuItem,
            this.mANAGERUBRICSToolStripMenuItem,
            this.mANAGEToolStripMenuItem,
            this.mARKEVALUATIONToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.menuStrip2.Size = new System.Drawing.Size(1753, 68);
            this.menuStrip2.TabIndex = 11;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // hOMEToolStripMenuItem
            // 
            this.hOMEToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.hOMEToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.hOMEToolStripMenuItem.Name = "hOMEToolStripMenuItem";
            this.hOMEToolStripMenuItem.Size = new System.Drawing.Size(104, 50);
            this.hOMEToolStripMenuItem.Text = "HOME";
            this.hOMEToolStripMenuItem.Click += new System.EventHandler(this.hOMEToolStripMenuItem_Click);
            // 
            // mANAGESTUDENTSToolStripMenuItem
            // 
            this.mANAGESTUDENTSToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGESTUDENTSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGESTUDENTSToolStripMenuItem.Name = "mANAGESTUDENTSToolStripMenuItem";
            this.mANAGESTUDENTSToolStripMenuItem.Padding = new System.Windows.Forms.Padding(7);
            this.mANAGESTUDENTSToolStripMenuItem.Size = new System.Drawing.Size(274, 50);
            this.mANAGESTUDENTSToolStripMenuItem.Text = "MANAGE STUDENTS";
            this.mANAGESTUDENTSToolStripMenuItem.Click += new System.EventHandler(this.mANAGESTUDENTSToolStripMenuItem_Click);
            // 
            // mANAGERUBRICSToolStripMenuItem
            // 
            this.mANAGERUBRICSToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGERUBRICSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGERUBRICSToolStripMenuItem.Name = "mANAGERUBRICSToolStripMenuItem";
            this.mANAGERUBRICSToolStripMenuItem.Size = new System.Drawing.Size(250, 50);
            this.mANAGERUBRICSToolStripMenuItem.Text = "MANAGE RUBRICS";
            this.mANAGERUBRICSToolStripMenuItem.Click += new System.EventHandler(this.mANAGERUBRICSToolStripMenuItem_Click);
            // 
            // mANAGEToolStripMenuItem
            // 
            this.mANAGEToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mANAGEToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mANAGEToolStripMenuItem.Name = "mANAGEToolStripMenuItem";
            this.mANAGEToolStripMenuItem.Size = new System.Drawing.Size(333, 50);
            this.mANAGEToolStripMenuItem.Text = "MANAGE RUBRICS LEVEL ";
            this.mANAGEToolStripMenuItem.Click += new System.EventHandler(this.mANAGEToolStripMenuItem_Click);
            // 
            // mARKEVALUATIONToolStripMenuItem
            // 
            this.mARKEVALUATIONToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mARKEVALUATIONToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.mARKEVALUATIONToolStripMenuItem.Name = "mARKEVALUATIONToolStripMenuItem";
            this.mARKEVALUATIONToolStripMenuItem.Size = new System.Drawing.Size(269, 50);
            this.mARKEVALUATIONToolStripMenuItem.Text = "MARK EVALUATION";
            this.mARKEVALUATIONToolStripMenuItem.Click += new System.EventHandler(this.mARKEVALUATIONToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(204, 50);
            this.toolStripMenuItem1.Text = "MANAGE CLOs";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(290, 50);
            this.toolStripMenuItem2.Text = "MANAGE ASSESMENT";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // marks
            // 
            this.marks.Location = new System.Drawing.Point(502, 164);
            this.marks.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.marks.Name = "marks";
            this.marks.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.marks.Size = new System.Drawing.Size(159, 26);
            this.marks.TabIndex = 41;
            this.marks.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // title
            // 
            this.title.Location = new System.Drawing.Point(502, 35);
            this.title.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(159, 26);
            this.title.TabIndex = 43;
            // 
            // weight
            // 
            this.weight.Location = new System.Drawing.Point(502, 99);
            this.weight.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.weight.Name = "weight";
            this.weight.Size = new System.Drawing.Size(159, 26);
            this.weight.TabIndex = 45;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(53, 70);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1177, 348);
            this.dataGridView1.TabIndex = 46;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(221, 497);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1276, 444);
            this.panel1.TabIndex = 50;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(24, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(225, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Assesements\'s Data";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.Update_Assesment);
            this.panel2.Controls.Add(this.Delete_Assesment);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.Add_Assesment);
            this.panel2.Controls.Add(this.weight);
            this.panel2.Controls.Add(this.marks);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.title);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(396, 99);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(960, 351);
            this.panel2.TabIndex = 51;
            // 
            // Update_Assesment
            // 
            this.Update_Assesment.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Update_Assesment.FlatAppearance.BorderSize = 0;
            this.Update_Assesment.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Update_Assesment.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Update_Assesment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Update_Assesment.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Update_Assesment.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Update_Assesment.Location = new System.Drawing.Point(422, 262);
            this.Update_Assesment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Update_Assesment.Name = "Update_Assesment";
            this.Update_Assesment.Size = new System.Drawing.Size(153, 54);
            this.Update_Assesment.TabIndex = 47;
            this.Update_Assesment.Text = "Update";
            this.Update_Assesment.UseVisualStyleBackColor = false;
            this.Update_Assesment.Click += new System.EventHandler(this.button5_Click);
            // 
            // Delete_Assesment
            // 
            this.Delete_Assesment.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Delete_Assesment.FlatAppearance.BorderSize = 0;
            this.Delete_Assesment.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Delete_Assesment.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Delete_Assesment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Delete_Assesment.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete_Assesment.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Delete_Assesment.Location = new System.Drawing.Point(725, 262);
            this.Delete_Assesment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Delete_Assesment.Name = "Delete_Assesment";
            this.Delete_Assesment.Size = new System.Drawing.Size(153, 54);
            this.Delete_Assesment.TabIndex = 46;
            this.Delete_Assesment.Text = "Delete";
            this.Delete_Assesment.UseVisualStyleBackColor = false;
            this.Delete_Assesment.Click += new System.EventHandler(this.button4_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(308, 164);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 20);
            this.label8.TabIndex = 18;
            this.label8.Text = "Total Marks";
            // 
            // Add_Assesment
            // 
            this.Add_Assesment.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Add_Assesment.FlatAppearance.BorderSize = 0;
            this.Add_Assesment.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Add_Assesment.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Add_Assesment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Add_Assesment.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_Assesment.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Add_Assesment.Location = new System.Drawing.Point(90, 262);
            this.Add_Assesment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Add_Assesment.Name = "Add_Assesment";
            this.Add_Assesment.Size = new System.Drawing.Size(153, 54);
            this.Add_Assesment.TabIndex = 14;
            this.Add_Assesment.Text = "Add";
            this.Add_Assesment.UseVisualStyleBackColor = false;
            this.Add_Assesment.Click += new System.EventHandler(this.student_addBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(308, 99);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Total Weightage";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(308, 41);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(127, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Assesement title";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // ManageAssesment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = global::database_mids_project.Properties.Resources._64e01bf1f7dbd9099e249e9c3247fdbb9a46b4b1_1280x7205;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1753, 972);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip2);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ManageAssesment";
            this.Text = "ManageAssesment";
            this.Load += new System.EventHandler(this.ManageAssesment_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem hOMEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGESTUDENTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGERUBRICSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mANAGEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mARKEVALUATIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.TextBox marks;
        private System.Windows.Forms.TextBox title;
        private System.Windows.Forms.TextBox weight;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button Add_Assesment;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Update_Assesment;
        private System.Windows.Forms.Button Delete_Assesment;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
    }
}