﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace database_mids_project
{
    public partial class Student_attendance : Form
    {
        public Student_attendance()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;

        }

        private void hOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();

            form1.Show();
            Visible = false;
        }

        private void Student_attendance_Load(object sender, EventArgs e)
        {
            MaximizeBox = false;
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Student;", con);
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            dataAdapter.SelectCommand = cmd;
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds);
            con.Close();
            RegCombo.DataSource = ds.Tables[0];
            RegCombo.DisplayMember = "RegistrationNumber";
            RegCombo.ValueMember = "ID";
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (RegCombo.SelectedItem == null)
            {
                errorProvider1.SetError(RegCombo, "Please select from the list below.");
                return;
            }
            if (comboBox1.SelectedItem == null)
            {
                errorProvider2.SetError(comboBox1, "Please select from the list below.");
                return;
            }
            SaveAttendanceDate();

        }
        private void SaveAttendanceDate()
        {
            ADDDate();
            int dateId = FindDateID();
            int studenId = FindStudentId();
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO StudentAttendance (AttendanceId, StudentId, AttendanceStatus) VALUES (@attendanceId, @studentId, @status)", con);
                if (studenId != -1)
                {
                    cmd.Parameters.AddWithValue("@studentId", studenId);
                }
                else
                {
                    return;
                }
                if (dateId != -1)
                {
                    cmd.Parameters.AddWithValue("@attendanceId", dateId);
                }
                else
                {
                    return;
                }
                int number = giveNumber();
                cmd.Parameters.AddWithValue("@status", number);
                cmd.ExecuteNonQuery();
                con.Close();

            }
            MessageBox.Show("Attendance added successfully", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void resetData()
        {
            RegCombo.Items.Clear();

        }


        private int giveNumber()
        {
            if (comboBox1.Text == "Present")
            {
                return 1;
            }
            else if (comboBox1.Text == "Absent")
            {
                return 2;
            }
            else if (comboBox1.Text == "Leave")
            {
                return 3;
            }
            else { return 4; }
        }




        private void ADDDate()
        {
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            if (!CheckDateExist())
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO ClassAttendance (AttendanceDate) VALUES (@date)", con);
                cmd.Parameters.AddWithValue("@date", Convert.ToDateTime(dateTimePicker1.Value));
                cmd.ExecuteNonQuery();
                con.Close();

            }

        }

        private int FindDateID()
        {
            int dateId = -1;
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from ClassAttendance where AttendanceDate = @date", con);
            cmd.Parameters.AddWithValue("@date", Convert.ToDateTime(dateTimePicker1.Value));

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                dateId = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return dateId;

        }

        private bool CheckDateExist()
        {
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select count(*)from ClassAttendance where AttendanceDate = @date", con);
            cmd.Parameters.AddWithValue("@date", Convert.ToDateTime(dateTimePicker1.Value));
            int count = (int)(cmd.ExecuteScalar());

            con.Close();
            return count > 0;



        }

        private int FindStudentId()
        {
            int studentId = -1;
            string constr = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=ProjectB1;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from Student where RegistrationNumber = @reg", con);
            cmd.Parameters.AddWithValue("@reg", RegCombo.Text);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                studentId = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return studentId;
        }

        private void mANAGESTUDENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manage_students mana = new Manage_students();
            mana.WindowState = FormWindowState.Maximized;

            mana.Show();
            Visible = false;
        }

        private void mANAGERUBRICSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubrics manage = new ManageRubrics();

            manage.Show();
            Visible = false;
        }

        private void mANAGEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageRubricsLevel man = new ManageRubricsLevel();

            man.Show();
            Visible = false;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ManageCLO newa = new ManageCLO();
            newa.WindowState = FormWindowState.Maximized;
            newa.Show();
            Visible = false;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ManageAssesment man = new ManageAssesment();
            man.WindowState = FormWindowState.Maximized;
            man.Show();
            Visible = false;
        }

        private void RegCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}